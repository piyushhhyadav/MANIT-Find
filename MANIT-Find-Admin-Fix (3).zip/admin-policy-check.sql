-- MANIT Find admin access migration
-- Run in Supabase SQL Editor. Does not modify or delete reports.
-- Allows an authenticated user to read only their own admin-list row.
drop policy if exists "Admins can read their own admin record" on public.site_admins;
create policy "Admins can read their own admin record"
on public.site_admins
for select
to authenticated
using (user_id = (select auth.uid()));

-- Grants the SQL operation to authenticated users; RLS still restricts which rows
-- they may update. Keep the existing "Admins can update reports" RLS policy.
grant select on public.site_admins to authenticated;
grant update on public.reports to authenticated;

# MANIT Find — refreshed interface

## Files
- `index.html` — redesigned page
- `styles.css` — new responsive visual design
- `script.js` — existing report/search/filter/detail logic
- `config.js` — Supabase browser configuration
- `supabase-setup.sql` — reference only; do not rerun without checking existing database

## Before testing
1. Open `config.js` in Notepad++. Check that `SUPABASE_URL` is your project's base URL, like `https://YOUR-PROJECT.supabase.co` (do not add `/rest/v1/`).
2. Keep the publishable/anon key only; never put a service-role or secret key in browser code.
3. Keep all files together in the same folder. Open `index.html` to preview; Supabase features require an internet connection.
4. Deploy the contents of this folder to Netlify so `index.html` and `styles.css` are at the site root. Then hard refresh with Ctrl+Shift+R.

The CSS and page layout were refreshed while retaining the existing IDs used by `script.js`. Test report submission, search, filters, View Details, and the finder email feature before replacing your current live site.


## Fix for admin resolve RLS error
1. In Supabase SQL Editor, run the full contents of `admin-resolve-function.sql`.
2. Deploy the updated website files (`index.html`, `styles.css`, `script.js`, `config.js`) to Netlify with `index.html` at the site root.
3. Keep RLS enabled and retain the existing policies.
4. Sign in as the account listed in `site_admins` and test on a temporary report.

The browser calls the `admin_resolve_report` RPC instead of directly updating `reports`. The function checks `auth.uid()` against `site_admins` before making the change. Do not add a public UPDATE policy or put a service-role key in browser files.

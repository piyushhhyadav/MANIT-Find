-- MANIT Find: secure admin-only report resolution
-- Run this in Supabase SQL Editor before deploying the updated script.js.
-- This function checks the signed-in user's UUID against site_admins and only
-- then changes an unresolved report. It does not disable RLS or change policies.

CREATE OR REPLACE FUNCTION public.admin_resolve_report(p_report_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT EXISTS (
    SELECT 1
    FROM public.site_admins AS sa
    WHERE sa.user_id = (SELECT auth.uid())
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;

  UPDATE public.reports
  SET is_resolved = true
  WHERE id = p_report_id
    AND is_resolved = false;

  RETURN FOUND;
END;
$$;

REVOKE ALL ON FUNCTION public.admin_resolve_report(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_resolve_report(uuid) TO authenticated;
